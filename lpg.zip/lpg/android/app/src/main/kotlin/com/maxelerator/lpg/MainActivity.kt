package com.maxelerator.lpg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
