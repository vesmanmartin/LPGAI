// ... Import statements here ...
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:http/http.dart' as http;
import 'details_screen.dart';

class QRScanner extends StatefulWidget {
  @override
  _QRScannerState createState() => _QRScannerState();
}

class _QRScannerState extends State<QRScanner> {
  late QRViewController _controller;
  String? _scannedData;
  String _responseBody = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('QR Code Reader')),
      body: Stack(
        alignment: AlignmentDirectional.topCenter,
        children: [
          QRView(
            key: Key('qrview'),
            onQRViewCreated: _onQRViewCreated,

          ),
          Positioned(
            top: 50,
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Center(
                child: ElevatedButton(
                  onPressed: () async {
                    if (_scannedData != null && _controller != null) {
                      try {
                        final response = await http.post(
                          Uri.parse('http://192.168.1.31:5001/get_cylinder_details'),
                          body: jsonEncode({"CylinderSerialNumber": _scannedData}),
                          headers: {
                            "Content-type": "application/json",
                          },
                        );

                        if (response.statusCode == 200) {
                          setState(() {
                            _responseBody = response.body;
                          });

                          Navigator.pushNamed(
                            context,
                            DetailsScreen.routeName,
                            arguments: {
                              'scannedData': _scannedData,
                              'responseBody': response.body,
                            },
                          );
                        } else {
                          throw Exception('Error while fetching from endpoint.');
                        }
                      } catch (e) {
                        setState(() {
                          _responseBody = e.toString();
                        });
                      } finally {
                        _controller.stopCamera();
                      }
                    }
                  },
                  child: Text('Submit'.toUpperCase()),
                ),
              ),
            ),
          ),
          Visibility(
            visible: _responseBody.isNotEmpty,
            maintainSize: true,
            maintainAnimation: true,
            maintainState: true,
            child: Card(
              margin: EdgeInsets.zero,
              elevation: 8,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Container(
                constraints: BoxConstraints(maxHeight: 250),
                padding: EdgeInsets.all(16),
                child: SingleChildScrollView(
                  child: Text(
                    _responseBody,
                    textAlign: TextAlign.start,
                    softWrap: true,
                    overflow: TextOverflow.fade,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    _controller = controller;
    controller.scannedDataStream.listen((event) {
      setState(() {
        _scannedData = event.code;
      });

      controller.stopCamera();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}