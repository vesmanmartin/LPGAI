import 'package:flutter/material.dart';

class DetailsScreen extends StatefulWidget {
  static const routeName = "/details-screen";

  final String scannedData;
  final String responseBody;

  const DetailsScreen({required this.scannedData, required this.responseBody});

  @override
  _DetailsScreenState createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(title: Text('Details Screen')),
        body: SafeArea(
          child: Column(
            children: [
              Flexible(
                child: ListTile(
                  leading: Icon(Icons.info),
                  title: Text('Scanned Data:'),
                  subtitle: SelectableText(widget.scannedData),
                ),
              ),
              Divider(),
              Flexible(
                child: ListTile(
                  dense: true,
                  visualDensity: VisualDensity(horizontal: 0, vertical: -4),
                  minLeadingWidth: 0,
                  contentPadding: EdgeInsets.only(left: 16, right: 16),
                  leading: Icon(Icons.description),
                  title: Text('Response:'),
                  subtitle: SelectableText(widget.responseBody),
                ),
              ),
              Spacer(),
              Container(
                height: kToolbarHeight + 16,
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Back'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}